package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Toyli04Application {

	public static void main(String[] args) {
		SpringApplication.run(Toyli04Application.class, args);
	}

}
